import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import cm
import numpy as np

plt.style.use('dark_background')
with open('normals.txt') as g:
    normals = g.readlines()
with open('pos.txt') as f:
    contents = f.readlines()
contents
coordinates = {}
xc = []
yc = []
for i in contents[1:]:
    x = i.split(" ")
    a = float(x[0])
    b = float(x[1])
    c = float(x[2])
    coordinates[a] = [b, c]
    xc.append(b)
    yc.append(c)

normalco = []
for k in normals[1:]:
    y = k.split(" ")
    a = float(y[0])
    b = float(y[1])
    c = float(y[5])
    normalco.append([a, b, c])

force = max([i[2] for i in normalco])
m = float(3) / float(force)

fig = plt.figure()
ax = fig.add_subplot()

norm = mpl.colors.Normalize(vmin=0, vmax=force)
cmap = mpl.cm.ScalarMappable(norm=norm, cmap=mpl.cm.RdYlGn_r)
cmap.set_array([])

for i in normalco:
    q = coordinates[i[0]]
    w = coordinates[i[1]]
    if abs(w[0] - q[0]) < 0.1 and abs(w[1] - q[1]) < 0.1:
        plt.plot([q[0], w[0]], [q[1], w[1]], '-', linewidth=m * i[2], c=cmap.to_rgba(i[2]))

plt.colorbar(cmap, ticks=np.linspace(0, force, 10))
plt.axis('off')
plt.xlim([-0.005,0.13])
plt.ylim([-0.005,0.13])
ax.set_aspect('equal', adjustable='box')
resolution_value = 1200
plt.savefig("ForceChain2D.png", format="png", dpi=resolution_value)